# eFootball PES 2021 Cheat Table

![](https://i.imgur.com/SphIZMR.png)
![enter image description here](https://i.imgur.com/AzuVU1N.gif)
## How to use in Master League Game Mode

 1. Activate Edit Player script
 2. In Game enter My Team Info -> Squad List -> Hover player you want to edit

## How to edit your player in Become a Legend Game Mode

 1. Activate Edit Player script
 2. In Game enter Game Menu -> My Data

## How to Edit player in other team (same in both game modes)

 1. Activate Edit Player Script
 2. In Game enter Database -> Team Info -> Pick Team -> Squad List -> Hover Player you want to edit

## How to edit Transfer/Salary Budget

 1. Activate Edit Club Budget
 2. In game go to "Team Management" -> "Negotiations"
 3. Edit values in Cheat Engine

## Features
 - Edit Focus Points in BAL Mode
 - Edit Club Budget
   -  Transfer Budget
   -  Salary Budget
 - Edit Player:
    - Age
    - Stronger Foot
    - Positions
    - Abilities
    - Team Role
    - Contract
    - And other misc stuff
 - Gameplay:
    - Match Time
    - Unlimited Stamina
